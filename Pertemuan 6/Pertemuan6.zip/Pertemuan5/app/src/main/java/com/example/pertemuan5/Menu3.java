package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Menu3 extends AppCompatActivity {
    EditText Txt_nama;
    TextView Lbl5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu3);

        Txt_nama = findViewById(R.id.Txt_nama);
        Lbl5 = findViewById(R.id.Lbl5);
    }

    public void Tampil_Hasil(View v){
        Lbl5.setText("Nama anda adalah : \n" + Txt_nama.getText());
    }
}
