package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Menu4 extends AppCompatActivity {
    EditText Txt_nama2;
    TextView Lbl8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu4);

        Txt_nama2 = findViewById(R.id.Txt_nama2);
        Lbl8 = findViewById(R.id.Lbl8);
    }

    public void Hasil_Akar(View v){
        String Hasil = Txt_nama2.getText().toString();
        int Akar = Integer.parseInt(Hasil);
        int x=1;
        int y=x*x;

        while(y != Akar){
            x++;
            y=x*x;

        }
        Lbl8.setText("Akarnya Adalah " + x);


    }
}
